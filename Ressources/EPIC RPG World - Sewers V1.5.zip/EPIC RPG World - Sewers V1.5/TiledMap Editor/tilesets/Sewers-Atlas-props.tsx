<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Atlas - props" tilewidth="32" tileheight="32" tilecount="3127" columns="59">
 <image source="../../Props/atlas-props.png" width="1899" height="1696"/>
 <tile id="928">
  <animation>
   <frame tileid="928" duration="100"/>
   <frame tileid="930" duration="100"/>
   <frame tileid="932" duration="100"/>
   <frame tileid="934" duration="100"/>
   <frame tileid="936" duration="100"/>
   <frame tileid="938" duration="100"/>
   <frame tileid="940" duration="100"/>
   <frame tileid="942" duration="100"/>
  </animation>
 </tile>
 <tile id="929">
  <animation>
   <frame tileid="929" duration="100"/>
   <frame tileid="931" duration="100"/>
   <frame tileid="933" duration="100"/>
   <frame tileid="935" duration="100"/>
   <frame tileid="937" duration="100"/>
   <frame tileid="939" duration="100"/>
   <frame tileid="941" duration="100"/>
   <frame tileid="943" duration="100"/>
  </animation>
 </tile>
 <tile id="987">
  <animation>
   <frame tileid="987" duration="100"/>
   <frame tileid="989" duration="100"/>
   <frame tileid="991" duration="100"/>
   <frame tileid="993" duration="100"/>
   <frame tileid="995" duration="100"/>
   <frame tileid="997" duration="100"/>
   <frame tileid="999" duration="100"/>
   <frame tileid="1001" duration="100"/>
  </animation>
 </tile>
 <tile id="988">
  <animation>
   <frame tileid="988" duration="100"/>
   <frame tileid="990" duration="100"/>
   <frame tileid="992" duration="100"/>
   <frame tileid="994" duration="100"/>
   <frame tileid="996" duration="100"/>
   <frame tileid="998" duration="100"/>
   <frame tileid="1000" duration="100"/>
   <frame tileid="1002" duration="100"/>
  </animation>
 </tile>
 <tile id="1105">
  <animation>
   <frame tileid="1105" duration="100"/>
   <frame tileid="1107" duration="100"/>
   <frame tileid="1109" duration="100"/>
   <frame tileid="1111" duration="100"/>
   <frame tileid="1113" duration="100"/>
   <frame tileid="1115" duration="100"/>
   <frame tileid="1117" duration="100"/>
   <frame tileid="1119" duration="100"/>
  </animation>
 </tile>
 <tile id="1106">
  <animation>
   <frame tileid="1106" duration="100"/>
   <frame tileid="1108" duration="100"/>
   <frame tileid="1110" duration="100"/>
   <frame tileid="1112" duration="100"/>
   <frame tileid="1114" duration="100"/>
   <frame tileid="1116" duration="100"/>
   <frame tileid="1118" duration="100"/>
   <frame tileid="1120" duration="100"/>
  </animation>
 </tile>
 <tile id="1164">
  <animation>
   <frame tileid="1164" duration="100"/>
   <frame tileid="1166" duration="100"/>
   <frame tileid="1168" duration="100"/>
   <frame tileid="1170" duration="100"/>
   <frame tileid="1172" duration="100"/>
   <frame tileid="1174" duration="100"/>
   <frame tileid="1176" duration="100"/>
   <frame tileid="1178" duration="100"/>
  </animation>
 </tile>
 <tile id="1165">
  <animation>
   <frame tileid="1165" duration="100"/>
   <frame tileid="1167" duration="100"/>
   <frame tileid="1169" duration="100"/>
   <frame tileid="1171" duration="100"/>
   <frame tileid="1173" duration="100"/>
   <frame tileid="1175" duration="100"/>
   <frame tileid="1177" duration="100"/>
   <frame tileid="1179" duration="100"/>
  </animation>
 </tile>
 <tile id="1223">
  <animation>
   <frame tileid="1223" duration="100"/>
   <frame tileid="1225" duration="100"/>
   <frame tileid="1227" duration="100"/>
   <frame tileid="1229" duration="100"/>
   <frame tileid="1231" duration="100"/>
   <frame tileid="1233" duration="100"/>
   <frame tileid="1235" duration="100"/>
   <frame tileid="1237" duration="100"/>
  </animation>
 </tile>
 <tile id="1224">
  <animation>
   <frame tileid="1224" duration="100"/>
   <frame tileid="1226" duration="100"/>
   <frame tileid="1228" duration="100"/>
   <frame tileid="1230" duration="100"/>
   <frame tileid="1232" duration="100"/>
   <frame tileid="1234" duration="100"/>
   <frame tileid="1236" duration="100"/>
   <frame tileid="1238" duration="100"/>
  </animation>
 </tile>
 <tile id="1282">
  <animation>
   <frame tileid="1282" duration="100"/>
   <frame tileid="1284" duration="100"/>
   <frame tileid="1286" duration="100"/>
   <frame tileid="1288" duration="100"/>
   <frame tileid="1290" duration="100"/>
   <frame tileid="1292" duration="100"/>
   <frame tileid="1294" duration="100"/>
   <frame tileid="1296" duration="100"/>
  </animation>
 </tile>
 <tile id="1283">
  <animation>
   <frame tileid="1283" duration="100"/>
   <frame tileid="1285" duration="100"/>
   <frame tileid="1287" duration="100"/>
   <frame tileid="1289" duration="100"/>
   <frame tileid="1291" duration="100"/>
   <frame tileid="1293" duration="100"/>
   <frame tileid="1295" duration="100"/>
   <frame tileid="1297" duration="100"/>
  </animation>
 </tile>
 <tile id="1341">
  <animation>
   <frame tileid="1341" duration="100"/>
   <frame tileid="1343" duration="100"/>
   <frame tileid="1345" duration="100"/>
   <frame tileid="1347" duration="100"/>
   <frame tileid="1349" duration="100"/>
   <frame tileid="1351" duration="100"/>
   <frame tileid="1353" duration="100"/>
   <frame tileid="1355" duration="100"/>
  </animation>
 </tile>
 <tile id="1342">
  <animation>
   <frame tileid="1342" duration="100"/>
   <frame tileid="1344" duration="100"/>
   <frame tileid="1346" duration="100"/>
   <frame tileid="1348" duration="100"/>
   <frame tileid="1350" duration="100"/>
   <frame tileid="1352" duration="100"/>
   <frame tileid="1354" duration="100"/>
   <frame tileid="1356" duration="100"/>
  </animation>
 </tile>
 <tile id="1400">
  <animation>
   <frame tileid="1400" duration="100"/>
   <frame tileid="1402" duration="100"/>
   <frame tileid="1404" duration="100"/>
   <frame tileid="1406" duration="100"/>
   <frame tileid="1408" duration="100"/>
   <frame tileid="1410" duration="100"/>
   <frame tileid="1412" duration="100"/>
   <frame tileid="1414" duration="100"/>
  </animation>
 </tile>
 <tile id="1401">
  <animation>
   <frame tileid="1401" duration="100"/>
   <frame tileid="1403" duration="100"/>
   <frame tileid="1405" duration="100"/>
   <frame tileid="1407" duration="100"/>
   <frame tileid="1409" duration="100"/>
   <frame tileid="1411" duration="100"/>
   <frame tileid="1413" duration="100"/>
   <frame tileid="1415" duration="100"/>
  </animation>
 </tile>
 <tile id="1518">
  <animation>
   <frame tileid="1518" duration="100"/>
   <frame tileid="1520" duration="100"/>
   <frame tileid="1522" duration="100"/>
   <frame tileid="1524" duration="100"/>
   <frame tileid="1526" duration="100"/>
   <frame tileid="1528" duration="100"/>
   <frame tileid="1530" duration="100"/>
  </animation>
 </tile>
 <tile id="1519">
  <animation>
   <frame tileid="1519" duration="100"/>
   <frame tileid="1521" duration="100"/>
   <frame tileid="1523" duration="100"/>
   <frame tileid="1525" duration="100"/>
   <frame tileid="1527" duration="100"/>
   <frame tileid="1529" duration="100"/>
   <frame tileid="1531" duration="100"/>
  </animation>
 </tile>
 <tile id="1636">
  <animation>
   <frame tileid="1636" duration="100"/>
   <frame tileid="1638" duration="100"/>
   <frame tileid="1640" duration="100"/>
   <frame tileid="1642" duration="100"/>
   <frame tileid="1644" duration="100"/>
   <frame tileid="1646" duration="100"/>
   <frame tileid="1648" duration="100"/>
  </animation>
 </tile>
 <tile id="1637">
  <animation>
   <frame tileid="1637" duration="100"/>
   <frame tileid="1639" duration="100"/>
   <frame tileid="1641" duration="100"/>
   <frame tileid="1643" duration="100"/>
   <frame tileid="1645" duration="100"/>
   <frame tileid="1647" duration="100"/>
   <frame tileid="1649" duration="100"/>
  </animation>
 </tile>
 <tile id="1754">
  <animation>
   <frame tileid="1754" duration="100"/>
   <frame tileid="1756" duration="100"/>
   <frame tileid="1758" duration="100"/>
   <frame tileid="1760" duration="100"/>
   <frame tileid="1762" duration="100"/>
   <frame tileid="1764" duration="100"/>
   <frame tileid="1766" duration="100"/>
  </animation>
 </tile>
 <tile id="1755">
  <animation>
   <frame tileid="1755" duration="100"/>
   <frame tileid="1757" duration="100"/>
   <frame tileid="1759" duration="100"/>
   <frame tileid="1761" duration="100"/>
   <frame tileid="1763" duration="100"/>
   <frame tileid="1765" duration="100"/>
   <frame tileid="1767" duration="100"/>
  </animation>
 </tile>
 <tile id="1872">
  <animation>
   <frame tileid="1872" duration="100"/>
   <frame tileid="1874" duration="100"/>
   <frame tileid="1876" duration="100"/>
   <frame tileid="1878" duration="100"/>
   <frame tileid="1880" duration="100"/>
   <frame tileid="1882" duration="100"/>
   <frame tileid="1884" duration="100"/>
  </animation>
 </tile>
 <tile id="1873">
  <animation>
   <frame tileid="1873" duration="100"/>
   <frame tileid="1875" duration="100"/>
   <frame tileid="1877" duration="100"/>
   <frame tileid="1879" duration="100"/>
   <frame tileid="1881" duration="100"/>
   <frame tileid="1883" duration="100"/>
   <frame tileid="1885" duration="100"/>
  </animation>
 </tile>
 <tile id="1914">
  <animation>
   <frame tileid="1914" duration="100"/>
   <frame tileid="1915" duration="100"/>
   <frame tileid="1916" duration="100"/>
   <frame tileid="1917" duration="100"/>
   <frame tileid="1918" duration="100"/>
   <frame tileid="1919" duration="100"/>
   <frame tileid="1920" duration="100"/>
   <frame tileid="1921" duration="100"/>
  </animation>
 </tile>
 <tile id="1973">
  <animation>
   <frame tileid="1973" duration="100"/>
   <frame tileid="1974" duration="100"/>
   <frame tileid="1975" duration="100"/>
   <frame tileid="1976" duration="100"/>
   <frame tileid="1977" duration="100"/>
   <frame tileid="1978" duration="100"/>
   <frame tileid="1979" duration="100"/>
   <frame tileid="1980" duration="100"/>
  </animation>
 </tile>
 <tile id="2032">
  <animation>
   <frame tileid="2032" duration="100"/>
   <frame tileid="2033" duration="100"/>
   <frame tileid="2034" duration="100"/>
   <frame tileid="2035" duration="100"/>
   <frame tileid="2036" duration="100"/>
   <frame tileid="2037" duration="100"/>
   <frame tileid="2038" duration="100"/>
   <frame tileid="2039" duration="100"/>
  </animation>
 </tile>
 <tile id="2047">
  <animation>
   <frame tileid="2047" duration="100"/>
   <frame tileid="2048" duration="100"/>
   <frame tileid="2049" duration="100"/>
   <frame tileid="2050" duration="100"/>
   <frame tileid="2051" duration="100"/>
   <frame tileid="2052" duration="100"/>
   <frame tileid="2053" duration="100"/>
   <frame tileid="2054" duration="100"/>
  </animation>
 </tile>
 <tile id="2056">
  <animation>
   <frame tileid="2056" duration="100"/>
   <frame tileid="2057" duration="100"/>
   <frame tileid="2058" duration="100"/>
   <frame tileid="2059" duration="100"/>
   <frame tileid="2060" duration="100"/>
   <frame tileid="2061" duration="100"/>
   <frame tileid="2062" duration="100"/>
   <frame tileid="2063" duration="100"/>
  </animation>
 </tile>
 <tile id="2091">
  <animation>
   <frame tileid="2091" duration="100"/>
   <frame tileid="2092" duration="100"/>
   <frame tileid="2093" duration="100"/>
   <frame tileid="2094" duration="100"/>
   <frame tileid="2095" duration="100"/>
   <frame tileid="2096" duration="100"/>
   <frame tileid="2097" duration="100"/>
   <frame tileid="2098" duration="100"/>
  </animation>
 </tile>
 <tile id="2165">
  <animation>
   <frame tileid="2165" duration="100"/>
   <frame tileid="2166" duration="100"/>
   <frame tileid="2167" duration="100"/>
   <frame tileid="2168" duration="100"/>
   <frame tileid="2169" duration="100"/>
   <frame tileid="2170" duration="100"/>
   <frame tileid="2171" duration="100"/>
   <frame tileid="2172" duration="100"/>
  </animation>
 </tile>
 <tile id="2174">
  <animation>
   <frame tileid="2174" duration="100"/>
   <frame tileid="2175" duration="100"/>
   <frame tileid="2176" duration="100"/>
   <frame tileid="2177" duration="100"/>
   <frame tileid="2178" duration="100"/>
   <frame tileid="2179" duration="100"/>
   <frame tileid="2180" duration="100"/>
   <frame tileid="2181" duration="100"/>
  </animation>
 </tile>
 <tile id="2209">
  <animation>
   <frame tileid="2209" duration="100"/>
   <frame tileid="2210" duration="100"/>
   <frame tileid="2211" duration="100"/>
   <frame tileid="2212" duration="100"/>
   <frame tileid="2213" duration="100"/>
   <frame tileid="2214" duration="100"/>
   <frame tileid="2215" duration="100"/>
   <frame tileid="2216" duration="100"/>
  </animation>
 </tile>
 <tile id="2224">
  <animation>
   <frame tileid="2224" duration="100"/>
   <frame tileid="2225" duration="100"/>
   <frame tileid="2226" duration="100"/>
   <frame tileid="2227" duration="100"/>
   <frame tileid="2228" duration="100"/>
   <frame tileid="2229" duration="100"/>
   <frame tileid="2230" duration="100"/>
   <frame tileid="2231" duration="100"/>
  </animation>
 </tile>
 <tile id="2233">
  <animation>
   <frame tileid="2233" duration="100"/>
   <frame tileid="2234" duration="100"/>
   <frame tileid="2235" duration="100"/>
   <frame tileid="2236" duration="100"/>
   <frame tileid="2237" duration="100"/>
   <frame tileid="2238" duration="100"/>
   <frame tileid="2239" duration="100"/>
   <frame tileid="2240" duration="100"/>
  </animation>
 </tile>
 <tile id="2268">
  <animation>
   <frame tileid="2268" duration="100"/>
   <frame tileid="2269" duration="100"/>
   <frame tileid="2270" duration="100"/>
   <frame tileid="2271" duration="100"/>
   <frame tileid="2272" duration="100"/>
   <frame tileid="2273" duration="100"/>
   <frame tileid="2274" duration="100"/>
   <frame tileid="2275" duration="100"/>
  </animation>
 </tile>
 <tile id="2283">
  <animation>
   <frame tileid="2283" duration="100"/>
   <frame tileid="2284" duration="100"/>
   <frame tileid="2285" duration="100"/>
   <frame tileid="2286" duration="100"/>
   <frame tileid="2287" duration="100"/>
   <frame tileid="2288" duration="100"/>
   <frame tileid="2289" duration="100"/>
   <frame tileid="2290" duration="100"/>
  </animation>
 </tile>
 <tile id="2292">
  <animation>
   <frame tileid="2292" duration="100"/>
   <frame tileid="2293" duration="100"/>
   <frame tileid="2294" duration="100"/>
   <frame tileid="2295" duration="100"/>
   <frame tileid="2296" duration="100"/>
   <frame tileid="2297" duration="100"/>
   <frame tileid="2298" duration="100"/>
   <frame tileid="2299" duration="100"/>
  </animation>
 </tile>
 <tile id="2327">
  <animation>
   <frame tileid="2327" duration="100"/>
   <frame tileid="2328" duration="100"/>
   <frame tileid="2329" duration="100"/>
   <frame tileid="2330" duration="100"/>
   <frame tileid="2331" duration="100"/>
   <frame tileid="2332" duration="100"/>
   <frame tileid="2333" duration="100"/>
   <frame tileid="2334" duration="100"/>
  </animation>
 </tile>
 <tile id="2386">
  <animation>
   <frame tileid="2386" duration="100"/>
   <frame tileid="2387" duration="100"/>
   <frame tileid="2388" duration="100"/>
   <frame tileid="2389" duration="100"/>
   <frame tileid="2390" duration="100"/>
   <frame tileid="2391" duration="100"/>
   <frame tileid="2392" duration="100"/>
   <frame tileid="2393" duration="100"/>
  </animation>
 </tile>
 <tile id="2504">
  <animation>
   <frame tileid="2504" duration="100"/>
   <frame tileid="2505" duration="100"/>
   <frame tileid="2506" duration="100"/>
   <frame tileid="2507" duration="100"/>
   <frame tileid="2508" duration="100"/>
   <frame tileid="2509" duration="100"/>
   <frame tileid="2510" duration="100"/>
   <frame tileid="2511" duration="100"/>
  </animation>
 </tile>
 <tile id="2563">
  <animation>
   <frame tileid="2563" duration="100"/>
   <frame tileid="2564" duration="100"/>
   <frame tileid="2565" duration="100"/>
   <frame tileid="2566" duration="100"/>
   <frame tileid="2567" duration="100"/>
   <frame tileid="2568" duration="100"/>
   <frame tileid="2569" duration="100"/>
   <frame tileid="2570" duration="100"/>
  </animation>
 </tile>
 <tile id="2622">
  <animation>
   <frame tileid="2622" duration="100"/>
   <frame tileid="2623" duration="100"/>
   <frame tileid="2624" duration="100"/>
   <frame tileid="2625" duration="100"/>
   <frame tileid="2626" duration="100"/>
   <frame tileid="2627" duration="100"/>
   <frame tileid="2628" duration="100"/>
   <frame tileid="2629" duration="100"/>
  </animation>
 </tile>
 <tile id="2681">
  <animation>
   <frame tileid="2681" duration="100"/>
   <frame tileid="2682" duration="100"/>
   <frame tileid="2683" duration="100"/>
   <frame tileid="2684" duration="100"/>
   <frame tileid="2685" duration="100"/>
   <frame tileid="2686" duration="100"/>
   <frame tileid="2687" duration="100"/>
   <frame tileid="2688" duration="100"/>
  </animation>
 </tile>
 <tile id="2799">
  <animation>
   <frame tileid="2799" duration="100"/>
   <frame tileid="2800" duration="100"/>
   <frame tileid="2801" duration="100"/>
   <frame tileid="2802" duration="100"/>
   <frame tileid="2803" duration="100"/>
   <frame tileid="2804" duration="100"/>
   <frame tileid="2805" duration="100"/>
   <frame tileid="2806" duration="100"/>
  </animation>
 </tile>
 <tile id="2858">
  <animation>
   <frame tileid="2858" duration="100"/>
   <frame tileid="2859" duration="100"/>
   <frame tileid="2860" duration="100"/>
   <frame tileid="2861" duration="100"/>
   <frame tileid="2862" duration="100"/>
   <frame tileid="2863" duration="100"/>
   <frame tileid="2864" duration="100"/>
   <frame tileid="2865" duration="100"/>
  </animation>
 </tile>
 <tile id="2917">
  <animation>
   <frame tileid="2917" duration="100"/>
   <frame tileid="2918" duration="100"/>
   <frame tileid="2919" duration="100"/>
   <frame tileid="2920" duration="100"/>
   <frame tileid="2921" duration="100"/>
   <frame tileid="2922" duration="100"/>
   <frame tileid="2923" duration="100"/>
   <frame tileid="2924" duration="100"/>
  </animation>
 </tile>
 <tile id="2976">
  <animation>
   <frame tileid="2976" duration="100"/>
   <frame tileid="2977" duration="100"/>
   <frame tileid="2978" duration="100"/>
   <frame tileid="2979" duration="100"/>
   <frame tileid="2980" duration="100"/>
   <frame tileid="2981" duration="100"/>
   <frame tileid="2982" duration="100"/>
   <frame tileid="2983" duration="100"/>
  </animation>
 </tile>
</tileset>
