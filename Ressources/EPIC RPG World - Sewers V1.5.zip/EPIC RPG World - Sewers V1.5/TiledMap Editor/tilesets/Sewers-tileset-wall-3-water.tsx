<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="wall-3-water" tilewidth="32" tileheight="32" tilecount="119" columns="17">
 <image source="../../Tilesets/wall-3-1- inner orientation-water.png" width="544" height="224"/>
 <tile id="5" probability="0"/>
 <tile id="6" probability="0"/>
 <tile id="7" probability="0"/>
 <tile id="8" probability="0"/>
 <tile id="9" probability="0"/>
 <tile id="10" probability="0"/>
 <tile id="17" probability="0"/>
 <tile id="21" probability="0"/>
 <tile id="22" probability="0"/>
 <tile id="23" probability="0"/>
 <tile id="24" probability="0"/>
 <tile id="25" probability="0"/>
 <tile id="26" probability="0"/>
 <tile id="27" probability="0"/>
 <tile id="34" probability="0"/>
 <tile id="38" probability="0"/>
 <tile id="39" probability="0"/>
 <tile id="40" probability="0"/>
 <tile id="41" probability="0"/>
 <tile id="42" probability="0"/>
 <tile id="43" probability="0"/>
 <tile id="44" probability="0"/>
 <tile id="56" probability="0"/>
 <tile id="57" probability="0"/>
 <tile id="58" probability="0"/>
 <tile id="59" probability="0"/>
 <tile id="60" probability="0"/>
 <tile id="61" probability="0"/>
 <tile id="73" probability="0"/>
 <tile id="74" probability="0"/>
 <tile id="75" probability="0"/>
 <tile id="76" probability="0"/>
 <tile id="77" probability="0"/>
 <tile id="78" probability="0"/>
 <tile id="90" probability="0"/>
 <tile id="91" probability="0"/>
 <tile id="92" probability="0"/>
 <tile id="93" probability="0"/>
 <tile id="94" probability="0"/>
 <tile id="95" probability="0"/>
 <wangsets>
  <wangset name="wall-3-water" type="corner" tile="19">
   <wangcolor name="" color="#ff0000" tile="19" probability="1"/>
   <wangtile tileid="1" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="2" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="3" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="17" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="18" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="20" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="21" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="34" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="38" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="51" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="53" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="55" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="68" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="69" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="71" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="72" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="73" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="74" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="86" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="87" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="88" wangid="0,0,0,0,0,0,0,1"/>
  </wangset>
 </wangsets>
</tileset>
